/*
 * copyright of philips 2020
 */
package document;

import java.util.ArrayList;

import converter.IDocumentConverter;
import converter.PDFConverter;
import converter.htmlConverter;

public class document {

    ArrayList<documentPart> parts = null;

    public static void main(final String[] args) {

        document obj = new document();
        obj.addDocument(new Header());
        obj.addDocument(new paragraph());
        obj.addDocument(new HyperLink());
        obj.convertToHtml();
        obj.convertToPDF();
    }

    public void open() {
    }

    public void close() {
    }

    public void save() {

    }

    public void addDocument(final documentPart pt) {
        parts.add(pt);
    }

    public void convertToHtml() {
        IDocumentConverter idc = new htmlConverter();
        for (documentPart pt : parts) {
            pt.convert(idc);
        }
    }

    public void convertToPDF() {
        IDocumentConverter idc = new PDFConverter();
        for (documentPart pt : parts) {
            pt.convert(idc);
        }
    }

}
