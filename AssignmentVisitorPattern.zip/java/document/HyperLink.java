/*
 * copyright of philips 2020
 */
package document;

import converter.IDocumentConverter;

public class HyperLink extends documentPart {

    @Override
    public void paint() {
        // TODO Auto-generated method stub

    }

    @Override
    public void save() {
        // TODO Auto-generated method stub

    }

    @Override
    public void convert(final IDocumentConverter idc) {
        idc.convertHyperlink(this);

    }

}
