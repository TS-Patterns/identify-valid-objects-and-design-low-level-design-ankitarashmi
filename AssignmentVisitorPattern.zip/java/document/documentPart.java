/*
 * copyright of philips 2020
 */
package document;

import converter.IDocumentConverter;

public abstract class documentPart {

    public abstract void paint();

    public abstract void save();

    public abstract void convert(final IDocumentConverter idc);
}
