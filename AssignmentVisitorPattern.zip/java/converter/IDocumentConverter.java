/*
 * copyright of philips 2020
 */
package converter;

import document.Header;
import document.HyperLink;
import document.paragraph;

public interface IDocumentConverter {
    void convertParagraph(final paragraph p);

    void convertHeader(Header h);

    void convertHyperlink(HyperLink hyperLink);

}
