/*
 * copyright of philips 2020
 */
package converter;

import document.Header;
import document.HyperLink;
import document.paragraph;

public class PDFConverter implements IDocumentConverter {

    public void convertParagraph(final paragraph p) {
        // TODO Auto-generated method stub

    }

    public void convertHeader(final Header h) {
        // TODO Auto-generated method stub

    }

    public void convertHyperlink(final HyperLink hyperLink) {
        // TODO Auto-generated method stub

    }

}
